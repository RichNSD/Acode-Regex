# Changelog

## 1.2.2

- README Overhaul.

## 1.2.1

- Adjustments to the README, mostly formatting fixes.

## 1.2.0

- Changed plugin name to "Regex Syntax" on both Acode and VSCode
- Icon redesign. Published design files to a new `/design` directory to allow for public use.
- Adjustments to the README, including AI Transparency disclosure.

## 1.1.0

- `.re` and `.regex` files show the plugin icon in the file browser and editor tabs (with Acode's default icon theme).

## 1.0.0

- Initial release: "Regular Expression" language for `.re` and `.regex` files, plus selectable JavaScript and Python regex flavours, with regex-aware completions.
